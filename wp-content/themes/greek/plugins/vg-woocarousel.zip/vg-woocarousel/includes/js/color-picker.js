jQuery(document).ready(function(jQuery) {
	jQuery('#vgwc_bg_color, #vgwc_ibg_color, #vgwc_itext_color, #vgwc_ilink_color, #vgwc_bbg_color, #vgwc_btext_color, #vgwc_salebg_color, #vgwc_saletext_color, #vgwc_hotbg_color, #vgwc_hottext_color').wpColorPicker();
});